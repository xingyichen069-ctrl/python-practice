class Student:
    def __init__(self,name,age,score):
        self.name=name
        self.age=age
        self.score=score
    
    def get_name(self):
        return self.name
    
    def get_age(self):
        return self.age
    
    def get_course(self):
        return max(self.score)
    
zm=Student('zhangming',20,[69,88,100])
x=zm.get_name()
y=zm.get_age()
z=zm.get_course()

print(x)
print(type(x))
print(y)
print(type(y))
print(f"最大分数为: {z}")
