#字符串是不可变对象
namelist=input("请输入一串字符，用空格分隔：").split()

namelist = [name.capitalize() for name in namelist]

namelist.sort(reverse=True)

print(*namelist)