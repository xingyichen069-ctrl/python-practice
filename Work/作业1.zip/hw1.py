def judge_range(x):
    if x<0 or x>1:
        return -1
    if 0<=x<0.08:
        return 1
    elif x<0.3:
        return 2
    else: 
        return 3

while True:   
    x=input("请输入一个在0到1范围内的整数,退出请按N：")
    if x=='N':break

    if judge_range(float(x))==-1:
        print("error")
    else: 
        print(judge_range(float(x)))
